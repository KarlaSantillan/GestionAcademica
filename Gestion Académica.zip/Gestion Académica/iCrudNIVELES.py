from iCrud import ICrud
from datetime import date
from utilities import borrarPantalla,gotoxy
from clsJson import JsonFile
from nivel import Nivel
import time
import os

path, file = os.path.split(__file__)

class CrudNiveles(ICrud):
    json_file = JsonFile(f"{path}/archivos/Niveles.json")  
    def create(self):
        borrarPantalla()
        print("Crear Nivel Académico")
        niveles = self.json_file.read()
        id_nivel = max([nivel["Id"] for nivel in niveles],default=0)+1
        nivel_descripcion = input("Ingrese el nivel académico (Ejemplo: Secundaria):...")
        nivel_nuevo = Nivel(id_nivel,nivel_descripcion)
        niveles.append(nivel_nuevo.getJson())
        self.json_file.save(niveles)
        
        print("Nivel Académico Creado exitosamente!")
        time.sleep(2)
        
    def update(self):
        borrarPantalla()
        print("Actualización de Niveles Académico")
        niveles = self.json_file.read()
        if niveles:
            id_nivel = int(input("Ingrese el ID del nivel académico: "))
            for nivel in niveles:
                if nivel['Id'] == id_nivel:
                    #Aquí mostramos la información del nivel que se busca
                    print(f"Nivel Actual: {nivel['Nivel']}   Fecha Creado:{nivel['Fecha_creacion']}   Activo:{nivel['Active']}")
                    
                    #Aquí ya vamos a pedir los datos para actualizarlo
                    nivel['Nivel'] = input("Ingrese el Nivel nuevo:")
                    nivel['Fecha_creacion'] = date.today().strftime('%Y-%m-%d')
                    #Con esto guardamos el nivel actualizado.
                    self.json_file.save(niveles)
                    print("Nivel Académico actualizado!")
                    time.sleep(2)
                else:
                    print("El nivel académico no se encuentra en la base de datos...")
        else:
            print("No hay niveles académicos registrados..")
            
    def delete(self):
        borrarPantalla()
        print("Eliminación de Niveles Académicos")
        niveles = self.json_file.read()
        if niveles:
            id_nivel = int(input("Ingrese el ID del nivel académico: "))
            for nivel in niveles:
                    if nivel['Id'] == id_nivel:
                        niveles.remove(nivel)
                        self.json_file.save(niveles)
                        print(f"Nivel con ID:{id_nivel} eliminado!")
                        time.sleep(2)
                        break
        else:
            print("No hay Niveles Académicos en el registro.")
            
    def consult(self):
        borrarPantalla()
        print("Consultar Niveles Académicos")
        niveles = self.json_file.read()
        if niveles:
            print("Niveles Académicos")
            for nivel in niveles:
                print(f"Id:{nivel['Id']} ||| Nivel:{nivel['Nivel']} ||| Fecha de Creación:{nivel['Fecha_creacion']} ||| Activo:{nivel['Active']}")
            input("Presione una tecla para salir...")
            borrarPantalla()
        else:
            print("No hay Niveles académicos")