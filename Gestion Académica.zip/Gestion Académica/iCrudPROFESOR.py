from iCrud import ICrud
from datetime import date
from utilities import borrarPantalla,gotoxy
from clsJson import JsonFile
from profesor import Profesor
import time
import os

path, file = os.path.split(__file__)

class CrudProfesor(ICrud):
    json_file = JsonFile(f"{path}/archivos/Profesores.json")
    def create(self):
        borrarPantalla()
        print("Crear nuevo profesor")
        profesores = self.json_file.read()
        id_profesor = max([profesor["Id"] for profesor in profesores],default=0)+1
        nombre = input("Ingrese el nombre del profesor:...")
        active = input("El profesor está activo? (si/no):").lower()
        active = True if active == 'si' else False
        profesor_nuevo = Profesor(id_profesor,nombre,active)
        profesores.append(profesor_nuevo.getJson())
        self.json_file.save(profesores)
        
        print("Profesor Creado exitosamente!")
        time.sleep(2)
        
    def update(self):
        borrarPantalla()
        print("Actualización de Profesor")
        profesores = self.json_file.read()
        if profesores:
            id_profesor = int(input("Ingrese el ID del profesor: "))
            for profesor in profesores:
                if profesor['Id'] == id_profesor:
                    #Aquí mostramos la información del periodo que se busca
                    print(f"Profesor: {profesor['Id']}   Nombre:{profesor['Nombre']}   Activo:{profesor['Active']}")
                    #Aquí ya vamos a pedir los datos para actualizarlo
                    profesor['Nombre'] = input("Ingrese el nombre del profesor:")
                    active = input("El profesor está activo? (si/no)").lower()
                    #Aquí según la opción asignamos si es True o False
                    active = True if active == 'si' else False
                    profesor['Active'] = active
                    #Con esto guardamos el periodo actualizado.
                    self.json_file.save(profesores)
                    print("Profesor actualizado!")
                    time.sleep(2)
                else:
                    print("El profesor no se encuentra en la base de datos...")
        else:
            print("No hay profesores registrados..")
            
    def delete(self):
        borrarPantalla()
        print("Eliminación de Profesor")
        profesores = self.json_file.read()
        if profesores:
            id_profesor = int(input("Ingrese el ID del profesor: "))
            for profesor in profesores:
                    if profesor['Id'] == id_profesor:
                        profesores.remove(profesor)
                        self.json_file.save(profesores)
                        print(f"Profesor con ID:{id_profesor} eliminado!")
                        time.sleep(2)
                        break
        else:
            print("No hay profesores en el registro.")
            
    def consult(self):
        borrarPantalla()
        print("Consultar Profesores")
        profesores = self.json_file.read()
        if profesores:
            print("Profesores")
            for profesor in profesores:
                print(f"Id:{profesor['Id']} ||| Nombre:{profesor['Nombre']} ||| Activo:{profesor['Active']}")
            input("Presione una tecla para salir...")
            borrarPantalla()
        else:
            print("No hay profesores")