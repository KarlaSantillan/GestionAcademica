from iCrud import ICrud
from datetime import date
from utilities import borrarPantalla, gotoxy
from clsJson import JsonFile
from periodo import Periodo
import time
import os

path, file = os.path.split(__file__)

class CrudPeriodo(ICrud):
    json_file = JsonFile(f"{path}/archivos/Periodos.json")

    def create(self):
        borrarPantalla()
        print("Crear nuevo periodo Académico")
        periodos = self.json_file.read()
        id_periodo = max([periodo["Id"] for periodo in periodos], default=0) + 1
        periodo_descripcion = input("Ingrese el nombre del periodo (Ejemplo: Semestre 1): ")
        active = input("El periodo está activo? (si/no): ").lower()
        active = True if active == 'si' else False
        periodo_nuevo = Periodo(id_periodo, periodo_descripcion, active)
        periodos.append(periodo_nuevo.getJson())
        self.json_file.save(periodos)

        print("Periodo Creado exitosamente!")
        time.sleep(2)

    def update(self):
        borrarPantalla()
        print("Actualización de Periodo Académico")
        periodos = self.json_file.read()
        if periodos:
            id_periodo = int(input("Ingrese el ID del periodo académico: "))
            for periodo in periodos:
                if periodo['Id'] == id_periodo:
                    # Mostrar la información del periodo actual
                    gotoxy(2, 4)
                    print(f"Periodo Actual: {periodo['Periodo']}   Fecha Creado: {periodo['Fecha_creacion']}   Activo: {periodo['Active']}")
                    
                    # Solicitar los nuevos datos
                    periodo['Periodo'] = input("Ingrese el periodo nuevo: ")
                    periodo['Fecha_creacion'] = date.today().strftime('%Y-%m-%d')
                    active = input("El periodo está activo? (si/no): ").lower()
                    active = True if active == 'si' else False
                    periodo['Active'] = active
                    
                    # Guardar el periodo actualizado
                    self.json_file.save(periodos)
                    print("Periodo actualizado!")
                    time.sleep(2)
                    break
            else:
                print("El periodo no se encuentra en la base de datos...")
        else:
            print("No hay periodos registrados..")

    def delete(self):
        borrarPantalla()
        print("Eliminación de Periodo Académico")
        periodos = self.json_file.read()
        if periodos:
            id_periodo = int(input("Ingrese el ID del periodo académico: "))
            for periodo in periodos:
                if periodo['Id'] == id_periodo:
                    periodos.remove(periodo)
                    self.json_file.save(periodos)
                    print(f"Periodo con ID: {id_periodo} eliminado!")
                    time.sleep(2)
                    break
            else:
                print("El periodo no se encuentra en la base de datos...")
        else:
            print("No hay periodos en el registro.")

    def consult(self):
        borrarPantalla()
        print("Consultar Periodos Académicos")
        periodos = self.json_file.read()
        if periodos:
            print(f"{'ID':<5} {'Periodo':<20} {'Fecha de Creación':<15} {'Activo':<6}")
            print("-" * 46)
            for periodo in periodos:
                gotoxy(2, 4 + periodos.index(periodo))
                print(f"{periodo['Id']:<5} {periodo['Periodo']:<20} {periodo['Fecha_creacion']:<15} {'Sí' if periodo['Active'] else 'No':<6}")
            input("Presione una tecla para salir...")
            borrarPantalla()
        else:
            print("No hay periodos académicos")
            time.sleep(2)
