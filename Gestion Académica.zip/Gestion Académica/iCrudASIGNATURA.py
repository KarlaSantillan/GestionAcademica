from iCrud import ICrud
from datetime import date
from utilities import borrarPantalla,gotoxy
from clsJson import JsonFile
from asignatura import Asignatura
import time
import os

path, file = os.path.split(__file__)

class CrudAsignatura(ICrud):
    json_file = JsonFile(f"{path}/archivos/Asignaturas.json")
    def create(self):
        borrarPantalla()
        print("Crear Asignatura Académico")
        asignaturas = self.json_file.read()
        id_asignatura = max([asignatura["Id"] for asignatura in asignaturas],default=0)+1
        asignatura_descripcion = input("Ingrese la asignatura (Ejemplo: Programación):...")
        nivel_asignatura =  input("Ingrese el nivel al que pertenece la asignatura (Ejemplo: 1er Nivel)...")
        active = input("La asignatura está activa? (si/no):").lower()
        active = True if active == 'si' else False
        asignatura_nueva = Asignatura(id_asignatura,asignatura_descripcion,nivel_asignatura,active)
        asignaturas.append(asignatura_nueva.getJson())
        self.json_file.save(asignaturas)
        
        print("Asignatura Creado exitosamente!")
        time.sleep(2)
        
    def update(self):
        borrarPantalla()
        print("Actualización de Asignatura")
        asignaturas = self.json_file.read()
        if asignaturas:
            id_asignatura = int(input("Ingrese el ID de la asignatura: "))
            for asignatura in asignaturas:
                if asignatura['Id'] == id_asignatura:
                    #Aquí mostramos la información del periodo que se busca
                    print(f"Asignatura Actual: {asignatura['Descripcion']}   Fecha Creado:{asignatura['Fecha_creacion']}   Nivel:{asignatura['Nivel']}   Activo:{asignatura['Active']}")
                    #Aquí ya vamos a pedir los datos para actualizarlo
                    asignatura['Descripcion'] = input("Ingrese la asignatura nueva:")
                    asignatura['Fecha_creacion'] = date.today().strftime('%Y-%m-%d')
                    asignatura['Nivel'] = input("Ingrese el nivel de la asignatura:")
                    active = input("La asignatura está activo? (si/no)").lower()
                    #Aquí según la opción asignamos si es True o False
                    active = True if active == 'si' else False
                    asignatura['Active'] = active
                    #Con esto guardamos el periodo actualizado.
                    self.json_file.save(asignaturas)
                    print("Asignatura actualizada!")
                    time.sleep(2)
                else:
                    print("La asignatura no se encuentra en la base de datos...")
        else:
            print("No hay asignaturas registrados..")
    def delete(self):
        borrarPantalla()
        print("Eliminación de asignatura")
        asignaturas = self.json_file.read()
        if asignaturas:
            id_asignatura = int(input("Ingrese el ID de la asignatura: "))
            for asignatura in asignaturas:
                    if asignatura['Id'] == id_asignatura:
                        asignaturas.remove(asignatura)
                        self.json_file.save(asignaturas)
                        print(f"Asignatura con ID:{id_asignatura} eliminada!")
                        time.sleep(2)
                        break
        else:
            print("No hay asignaturas en el registro.")
            
    def consult(self):
        borrarPantalla()
        print("Consultar Asignaturas")
        asignaturas = self.json_file.read()
        if asignaturas:
            print("Asignaturas")
            for asignatura in asignaturas:
                print(f"Id:{asignatura['Id']} ||| Asignatura:{asignatura['Descripcion']} ||| Fecha de Creación:{asignatura['Fecha_creacion']} ||| Nivel:{asignatura['Nivel']} ||| Activo:{asignatura['Active']}")
            input("Presione una tecla para salir...")
            borrarPantalla()
        else:
            print("No hay Asignaturas")