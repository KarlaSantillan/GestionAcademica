from iCrud import ICrud
from datetime import date
from utilities import borrarPantalla,gotoxy
from clsJson import JsonFile
from estudiante import Estudiante
import time
import os

path, file = os.path.split(__file__)

class CrudEstudiante(ICrud):
    json_file = JsonFile(f"{path}/archivos/Estudiantes.json")
    def create(self):
        borrarPantalla()
        print("Crear nuevo Estudiante")
        estudiantes = self.json_file.read()
        id_estudiante = max([estudiante["Id"] for estudiante in estudiantes],default=0)+1
        nombre = input("Ingrese el nombre del estudiante:...")
        active = input("El estudiante está activo? (si/no):").lower()
        active = True if active == 'si' else False
        estudiante_nuevo = Estudiante(id_estudiante,nombre,active)
        estudiantes.append(estudiante_nuevo.getJson())
        self.json_file.save(estudiantes)
        
        print("Estudiante Creado exitosamente!")
        time.sleep(2)
        
    def update(self):
        borrarPantalla()
        print("Actualización de Estudiante")
        estudiantes = self.json_file.read()
        if estudiantes:
            id_estudiante = int(input("Ingrese el ID del estudiante: "))
            for estudiante in estudiantes:
                if estudiante['Id'] == id_estudiante:
                    #Aquí mostramos la información del periodo que se busca
                    print(f"Estudiante: {estudiante['Id']}   Nombre:{estudiante['Nombre']}   Activo:{estudiante['Active']}")
                    #Aquí ya vamos a pedir los datos para actualizarlo
                    estudiante['Nombre'] = input("Ingrese el nombre del estudiante:")
                    active = input("El estudiante está activo? (si/no)").lower()
                    #Aquí según la opción asignamos si es True o False
                    active = True if active == 'si' else False
                    estudiante['Active'] = active
                    #Con esto guardamos el periodo actualizado.
                    self.json_file.save(estudiantes)
                    print("Estudiante actualizado!")
                    time.sleep(2)
                else:
                    print("El estudiante no se encuentra en la base de datos...")
        else:
            print("No hay estudiantes registrados..")
            
    def delete(self):
        borrarPantalla()
        print("Eliminación de Estudiante")
        estudiantes = self.json_file.read()
        if estudiantes:
            id_estudiante = int(input("Ingrese el ID del estudiante: "))
            for estudiante in estudiantes:
                    if estudiante['Id'] == id_estudiante:
                        estudiantes.remove(estudiante)
                        self.json_file.save(estudiantes)
                        print(f"Estudiante con ID:{id_estudiante} eliminado!")
                        time.sleep(2)
                        break
        else:
            print("No hay estudiantes en el registro.")
            
    def consult(self):
        borrarPantalla()
        print("Consultar Estudiantes")
        estudiantes = self.json_file.read()
        if estudiantes:
            print("Estudiantes")
            for estudiante in estudiantes:
                print(f"Id:{estudiante['Id']} ||| Nombre:{estudiante['Nombre']} ||| Activo:{estudiante['Active']}")
            input("Presione una tecla para salir...")
            borrarPantalla()
        else:
            print("No hay estudiantes")